# **[1.0.2] - 2022/01/07**

- Slightly all changed biome-variant texture & colours, because I forgot to..

---

# **[1.0.1] - 2022/01/07**

- Changed `dead_bush1` texture
- Changed `dead_bush3` model to use `dead_bush2` instead of `dead_bush1`

---

# **[1.0.0] - 2021/01/02**

- Release